###############################################################################
#
# The MIT License (MIT)
#
# Copyright (c) typedef int GmbH
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#
###############################################################################

import zlib

from autobahn.exception import PayloadExceededError
from autobahn.util import public
from autobahn.websocket.compress_base import (
    PerMessageCompress,
    PerMessageCompressOffer,
    PerMessageCompressOfferAccept,
    PerMessageCompressResponse,
    PerMessageCompressResponseAccept,
)

__all__ = (
    "PerMessageDeflate",
    "PerMessageDeflateMixin",
    "PerMessageDeflateOffer",
    "PerMessageDeflateOfferAccept",
    "PerMessageDeflateResponse",
    "PerMessageDeflateResponseAccept",
)


class PerMessageDeflateMixin:
    """
    Mixin class for this extension.
    """

    EXTENSION_NAME = "permessage-deflate"
    """
    Name of this WebSocket extension.
    """

    WINDOW_SIZE_PERMISSIBLE_VALUES = [9, 10, 11, 12, 13, 14, 15]
    """
    Permissible value for window size parameter.
    Higher values use more memory, but produce smaller output. The default is 15.
    """

    MEM_LEVEL_PERMISSIBLE_VALUES = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    """
    Permissible value for memory level parameter.
    Higher values use more memory, but are faster and produce smaller output. The default is 8.
    """


@public
class PerMessageDeflateOffer(PerMessageCompressOffer, PerMessageDeflateMixin):
    """
    Set of extension parameters for `permessage-deflate` WebSocket extension
    offered by a client to a server.
    """

    @classmethod
    def parse(cls, params):
        """
        Parses a WebSocket extension offer for `permessage-deflate` provided by a client to a server.

        :param params: Output from :func:`autobahn.websocket.WebSocketProtocol._parseExtensionsHeader`.
        :type params: list

        :returns: A new instance of :class:`autobahn.compress.PerMessageDeflateOffer`.
        :rtype: obj
        """

        # extension parameter defaults
        accept_max_window_bits = False
        accept_no_context_takeover = True
        # accept_no_context_takeover = False # FIXME: this may change in draft
        request_max_window_bits = 0
        request_no_context_takeover = False

        # verify/parse client ("client-to-server direction") parameters of permessage-deflate offer
        for p in params:
            if len(params[p]) > 1:
                raise Exception(
                    f"multiple occurrence of extension parameter '{p}' for extension '{cls.EXTENSION_NAME}'"
                )

            val = params[p][0]

            if p == "client_max_window_bits":
                #
                # see: https://tools.ietf.org/html/draft-ietf-hybi-permessage-compression-18
                # 8.1.2.2. client_max_window_bits

                # ".. This parameter has no value or a decimal integer value without
                # leading zeroes between 9 to 15 inclusive ..""

                # noinspection PySimplifyBooleanCheck
                if val is not True:
                    try:
                        val = int(val)
                    except:
                        raise Exception(
                            f"illegal extension parameter value '{val}' for parameter '{p}' of extension '{cls.EXTENSION_NAME}'"
                        )
                    else:
                        if (
                            val
                            not in PerMessageDeflateMixin.WINDOW_SIZE_PERMISSIBLE_VALUES
                        ):
                            raise Exception(
                                f"illegal extension parameter value '{val}' for parameter '{p}' of extension '{cls.EXTENSION_NAME}'"
                            )
                        else:
                            # FIXME (maybe): possibly forward/process the client hint!
                            # accept_max_window_bits = val
                            accept_max_window_bits = True
                else:
                    accept_max_window_bits = True

            elif p == "client_no_context_takeover":
                # noinspection PySimplifyBooleanCheck
                if val is not True:
                    raise Exception(
                        f"illegal extension parameter value '{val}' for parameter '{p}' of extension '{cls.EXTENSION_NAME}'"
                    )
                else:
                    accept_no_context_takeover = True

            elif p == "server_max_window_bits":
                try:
                    val = int(val)
                except:
                    raise Exception(
                        f"illegal extension parameter value '{val}' for parameter '{p}' of extension '{cls.EXTENSION_NAME}'"
                    )
                else:
                    if val not in PerMessageDeflateMixin.WINDOW_SIZE_PERMISSIBLE_VALUES:
                        raise Exception(
                            f"illegal extension parameter value '{val}' for parameter '{p}' of extension '{cls.EXTENSION_NAME}'"
                        )
                    else:
                        request_max_window_bits = val

            elif p == "server_no_context_takeover":
                # noinspection PySimplifyBooleanCheck
                if val is not True:
                    raise Exception(
                        f"illegal extension parameter value '{val}' for parameter '{p}' of extension '{cls.EXTENSION_NAME}'"
                    )
                else:
                    request_no_context_takeover = True

            else:
                raise Exception(
                    f"illegal extension parameter '{p}' for extension '{cls.EXTENSION_NAME}'"
                )

        offer = cls(
            accept_no_context_takeover,
            accept_max_window_bits,
            request_no_context_takeover,
            request_max_window_bits,
        )
        return offer

    def __init__(
        self,
        accept_no_context_takeover=True,
        accept_max_window_bits=True,
        request_no_context_takeover=False,
        request_max_window_bits=0,
    ):
        """

        :param accept_no_context_takeover: When ``True``, the client accepts the "no context takeover" feature.
        :type accept_no_context_takeover: bool
        :param accept_max_window_bits: When ``True``, the client accepts setting "max window size".
        :type accept_max_window_bits: bool
        :param request_no_context_takeover: When ``True``, the client request the "no context takeover" feature.
        :type request_no_context_takeover: bool
        :param request_max_window_bits: When non-zero, the client requests the given "max window size" (must be
            and integer from the interval ``[9..15]``).
        :type request_max_window_bits: int
        """
        if type(accept_no_context_takeover) != bool:
            raise Exception(
                f"invalid type {type(accept_no_context_takeover)} for accept_no_context_takeover"
            )

        self.accept_no_context_takeover = accept_no_context_takeover

        if type(accept_max_window_bits) != bool:
            raise Exception(
                f"invalid type {type(accept_max_window_bits)} for accept_max_window_bits"
            )

        self.accept_max_window_bits = accept_max_window_bits

        if type(request_no_context_takeover) != bool:
            raise Exception(
                f"invalid type {type(request_no_context_takeover)} for request_no_context_takeover"
            )

        self.request_no_context_takeover = request_no_context_takeover

        if (
            request_max_window_bits != 0
            and request_max_window_bits not in self.WINDOW_SIZE_PERMISSIBLE_VALUES
        ):
            raise Exception(
                f"invalid value {request_max_window_bits} for request_max_window_bits - permissible values {self.WINDOW_SIZE_PERMISSIBLE_VALUES}"
            )

        self.request_max_window_bits = request_max_window_bits

    def get_extension_string(self):
        """
        Returns the WebSocket extension configuration string as sent to the server.

        :returns: PMCE configuration string.
        :rtype: str
        """
        pmce_string = self.EXTENSION_NAME
        if self.accept_no_context_takeover:
            pmce_string += "; client_no_context_takeover"
        if self.accept_max_window_bits:
            pmce_string += "; client_max_window_bits"
        if self.request_no_context_takeover:
            pmce_string += "; server_no_context_takeover"
        if self.request_max_window_bits != 0:
            pmce_string += f"; server_max_window_bits={self.request_max_window_bits}"
        return pmce_string

    def __json__(self):
        """
        Returns a JSON serializable object representation.

        :returns: JSON serializable representation.
        :rtype: dict
        """
        return {
            "extension": self.EXTENSION_NAME,
            "accept_no_context_takeover": self.accept_no_context_takeover,
            "accept_max_window_bits": self.accept_max_window_bits,
            "request_no_context_takeover": self.request_no_context_takeover,
            "request_max_window_bits": self.request_max_window_bits,
        }

    def __repr__(self):
        """
        Returns Python object representation that can be eval'ed to reconstruct the object.

        :returns: Python string representation.
        :rtype: str
        """
        return (
            f"PerMessageDeflateOffer(accept_no_context_takeover = {self.accept_no_context_takeover}, accept_max_window_bits = {self.accept_max_window_bits}, request_no_context_takeover = {self.request_no_context_takeover}, request_max_window_bits = {self.request_max_window_bits})"
        )


@public
class PerMessageDeflateOfferAccept(
    PerMessageCompressOfferAccept, PerMessageDeflateMixin
):
    """
    Set of parameters with which to accept an `permessage-deflate` offer
    from a client by a server.
    """

    def __init__(
        self,
        offer,
        request_no_context_takeover=False,
        request_max_window_bits=0,
        no_context_takeover=None,
        window_bits=None,
        mem_level=None,
        max_message_size=None,
    ):
        """

        :param offer: The offer being accepted.
        :type offer: Instance of :class:`autobahn.compress.PerMessageDeflateOffer`.
        :param request_no_context_takeover: When ``True``, the server requests the "no context takeover" feature.
        :type request_no_context_takeover: bool
        :param request_max_window_bits: When non-zero, the server requests the given "max window size" (must be
            and integer from the interval ``[9..15]``).
        :param request_max_window_bits: int
        :param no_context_takeover: Override server ("server-to-client direction") context takeover (this must
                be compatible with the offer).
        :type no_context_takeover: bool
        :param window_bits: Override server ("server-to-client direction") window size (this must be
                compatible with the offer).
        :type window_bits: int
        :param mem_level: Set server ("server-to-client direction") memory level.
        :type mem_level: int
        """
        if not isinstance(offer, PerMessageDeflateOffer):
            raise Exception(f"invalid type {type(offer)} for offer")

        self.offer = offer

        if type(request_no_context_takeover) != bool:
            raise Exception(
                f"invalid type {type(request_no_context_takeover)} for request_no_context_takeover"
            )

        if request_no_context_takeover and not offer.accept_no_context_takeover:
            raise Exception(
                f"invalid value {request_no_context_takeover} for request_no_context_takeover - feature unsupported by client"
            )

        self.request_no_context_takeover = request_no_context_takeover

        if (
            request_max_window_bits != 0
            and request_max_window_bits not in self.WINDOW_SIZE_PERMISSIBLE_VALUES
        ):
            raise Exception(
                f"invalid value {request_max_window_bits} for request_max_window_bits - permissible values {self.WINDOW_SIZE_PERMISSIBLE_VALUES}"
            )

        if request_max_window_bits != 0 and not offer.accept_max_window_bits:
            raise Exception(
                f"invalid value {request_max_window_bits} for request_max_window_bits - feature unsupported by client"
            )

        self.request_max_window_bits = request_max_window_bits

        if no_context_takeover is not None:
            if type(no_context_takeover) != bool:
                raise Exception(
                    f"invalid type {type(no_context_takeover)} for no_context_takeover"
                )

            if offer.request_no_context_takeover and not no_context_takeover:
                raise Exception(
                    f"invalid value {no_context_takeover} for no_context_takeover - client requested feature"
                )

        self.no_context_takeover = no_context_takeover

        if window_bits is not None:
            if window_bits not in self.WINDOW_SIZE_PERMISSIBLE_VALUES:
                raise Exception(
                    f"invalid value {window_bits} for window_bits - permissible values {self.WINDOW_SIZE_PERMISSIBLE_VALUES}"
                )

            if (
                offer.request_max_window_bits != 0
                and window_bits > offer.request_max_window_bits
            ):
                raise Exception(
                    f"invalid value {window_bits} for window_bits - client requested lower maximum value"
                )

        self.window_bits = window_bits

        if mem_level is not None:
            if mem_level not in self.MEM_LEVEL_PERMISSIBLE_VALUES:
                raise Exception(
                    f"invalid value {mem_level} for mem_level - permissible values {self.MEM_LEVEL_PERMISSIBLE_VALUES}"
                )

        self.mem_level = mem_level
        self.max_message_size = max_message_size  # clamp/check values..?

    def get_extension_string(self):
        """
        Returns the WebSocket extension configuration string as sent to the server.

        :returns: PMCE configuration string.
        :rtype: str
        """
        pmce_string = self.EXTENSION_NAME
        if self.offer.request_no_context_takeover:
            pmce_string += "; server_no_context_takeover"
        if self.offer.request_max_window_bits != 0:
            pmce_string += (
                f"; server_max_window_bits={self.offer.request_max_window_bits}"
            )
        if self.request_no_context_takeover:
            pmce_string += "; client_no_context_takeover"
        if self.request_max_window_bits != 0:
            pmce_string += f"; client_max_window_bits={self.request_max_window_bits}"
        return pmce_string

    def __json__(self):
        """
        Returns a JSON serializable object representation.

        :returns: JSON serializable representation.
        :rtype: dict
        """
        return {
            "extension": self.EXTENSION_NAME,
            "offer": self.offer.__json__(),
            "request_no_context_takeover": self.request_no_context_takeover,
            "request_max_window_bits": self.request_max_window_bits,
            "no_context_takeover": self.no_context_takeover,
            "window_bits": self.window_bits,
            "mem_level": self.mem_level,
            "max_message_size": self.max_message_size,
        }

    def __repr__(self):
        """
        Returns Python object representation that can be eval'ed to reconstruct the object.

        :returns: Python string representation.
        :rtype: str
        """
        return (
            f"PerMessageDeflateOfferAccept(offer = {self.offer.__repr__()}, request_no_context_takeover = {self.request_no_context_takeover}, request_max_window_bits = {self.request_max_window_bits}, no_context_takeover = {self.no_context_takeover}, window_bits = {self.window_bits}, mem_level = {self.mem_level}, max_message_size = {self.max_message_size})"
        )


@public
class PerMessageDeflateResponse(PerMessageCompressResponse, PerMessageDeflateMixin):
    """
    Set of parameters for `permessage-deflate` responded by server.
    """

    @classmethod
    def parse(cls, params):
        """
        Parses a WebSocket extension response for `permessage-deflate` provided by a server to a client.

        :param params: Output from :func:`autobahn.websocket.WebSocketProtocol._parseExtensionsHeader`.
        :type params: list

        :returns: A new instance of :class:`autobahn.compress.PerMessageDeflateResponse`.
        :rtype: obj
        """
        client_max_window_bits = 0
        client_no_context_takeover = False
        server_max_window_bits = 0
        server_no_context_takeover = False

        for p in params:
            if len(params[p]) > 1:
                raise Exception(
                    f"multiple occurrence of extension parameter '{p}' for extension '{cls.EXTENSION_NAME}'"
                )

            val = params[p][0]

            if p == "client_max_window_bits":
                try:
                    val = int(val)
                except:
                    raise Exception(
                        f"illegal extension parameter value '{val}' for parameter '{p}' of extension '{cls.EXTENSION_NAME}'"
                    )
                else:
                    if val not in PerMessageDeflateMixin.WINDOW_SIZE_PERMISSIBLE_VALUES:
                        raise Exception(
                            f"illegal extension parameter value '{val}' for parameter '{p}' of extension '{cls.EXTENSION_NAME}'"
                        )
                    else:
                        client_max_window_bits = val

            elif p == "client_no_context_takeover":
                # noinspection PySimplifyBooleanCheck
                if val is not True:
                    raise Exception(
                        f"illegal extension parameter value '{val}' for parameter '{p}' of extension '{cls.EXTENSION_NAME}'"
                    )
                else:
                    client_no_context_takeover = True

            elif p == "server_max_window_bits":
                try:
                    val = int(val)
                except:
                    raise Exception(
                        f"illegal extension parameter value '{val}' for parameter '{p}' of extension '{cls.EXTENSION_NAME}'"
                    )
                else:
                    if val not in PerMessageDeflateMixin.WINDOW_SIZE_PERMISSIBLE_VALUES:
                        raise Exception(
                            f"illegal extension parameter value '{val}' for parameter '{p}' of extension '{cls.EXTENSION_NAME}'"
                        )
                    else:
                        server_max_window_bits = val

            elif p == "server_no_context_takeover":
                # noinspection PySimplifyBooleanCheck
                if val is not True:
                    raise Exception(
                        f"illegal extension parameter value '{val}' for parameter '{p}' of extension '{cls.EXTENSION_NAME}'"
                    )
                else:
                    server_no_context_takeover = True

            else:
                raise Exception(
                    f"illegal extension parameter '{p}' for extension '{cls.EXTENSION_NAME}'"
                )

        response = cls(
            client_max_window_bits,
            client_no_context_takeover,
            server_max_window_bits,
            server_no_context_takeover,
        )
        return response

    def __init__(
        self,
        client_max_window_bits,
        client_no_context_takeover,
        server_max_window_bits,
        server_no_context_takeover,
    ):
        """

        :param client_max_window_bits: FIXME
        :type client_max_window_bits: int
        :param client_no_context_takeover: FIXME
        :type client_no_context_takeover: bool
        :param server_max_window_bits: FIXME
        :type server_max_window_bits: int
        :param server_no_context_takeover: FIXME
        :type server_no_context_takeover: bool
        """
        self.client_max_window_bits = client_max_window_bits
        self.client_no_context_takeover = client_no_context_takeover
        self.server_max_window_bits = server_max_window_bits
        self.server_no_context_takeover = server_no_context_takeover

    def __json__(self):
        """
        Returns a JSON serializable object representation.

        :returns: JSON serializable representation.
        :rtype: dict
        """
        return {
            "extension": self.EXTENSION_NAME,
            "client_max_window_bits": self.client_max_window_bits,
            "client_no_context_takeover": self.client_no_context_takeover,
            "server_max_window_bits": self.server_max_window_bits,
            "server_no_context_takeover": self.server_no_context_takeover,
        }

    def __repr__(self):
        """
        Returns Python object representation that can be eval'ed to reconstruct the object.

        :returns: Python string representation.
        :rtype: str
        """
        return (
            f"PerMessageDeflateResponse(client_max_window_bits = {self.client_max_window_bits}, client_no_context_takeover = {self.client_no_context_takeover}, server_max_window_bits = {self.server_max_window_bits}, server_no_context_takeover = {self.server_no_context_takeover})"
        )


@public
class PerMessageDeflateResponseAccept(
    PerMessageCompressResponseAccept, PerMessageDeflateMixin
):
    """
    Set of parameters with which to accept an `permessage-deflate` response
    from a server by a client.
    """

    def __init__(
        self,
        response,
        no_context_takeover=None,
        window_bits=None,
        mem_level=None,
        max_message_size=None,
    ):
        """

        :param response: The response being accepted.
        :type response: Instance of :class:`autobahn.compress.PerMessageDeflateResponse`.
        :param no_context_takeover: Override client ("client-to-server direction") context takeover (this must be compatible with response).
        :type no_context_takeover: bool
        :param window_bits: Override client ("client-to-server direction") window size (this must be compatible with response).
        :type window_bits: int
        :param mem_level: Set client ("client-to-server direction") memory level.
        :type mem_level: int
        """
        if not isinstance(response, PerMessageDeflateResponse):
            raise Exception(f"invalid type {type(response)} for response")

        self.response = response

        if no_context_takeover is not None:
            if type(no_context_takeover) != bool:
                raise Exception(
                    f"invalid type {type(no_context_takeover)} for no_context_takeover"
                )

            if response.client_no_context_takeover and not no_context_takeover:
                raise Exception(
                    f"invalid value {no_context_takeover} for no_context_takeover - server requested feature"
                )

        self.no_context_takeover = no_context_takeover

        if window_bits is not None:
            if window_bits not in self.WINDOW_SIZE_PERMISSIBLE_VALUES:
                raise Exception(
                    f"invalid value {window_bits} for window_bits - permissible values {self.WINDOW_SIZE_PERMISSIBLE_VALUES}"
                )

            if (
                response.client_max_window_bits != 0
                and window_bits > response.client_max_window_bits
            ):
                raise Exception(
                    f"invalid value {window_bits} for window_bits - server requested lower maximum value"
                )

        self.window_bits = window_bits

        if mem_level is not None:
            if mem_level not in self.MEM_LEVEL_PERMISSIBLE_VALUES:
                raise Exception(
                    f"invalid value {mem_level} for mem_level - permissible values {self.MEM_LEVEL_PERMISSIBLE_VALUES}"
                )

        self.mem_level = mem_level
        self.max_message_size = max_message_size

    def __json__(self):
        """
        Returns a JSON serializable object representation.

        :returns: JSON serializable representation.
        :rtype: dict
        """
        return {
            "extension": self.EXTENSION_NAME,
            "response": self.response.__json__(),
            "no_context_takeover": self.no_context_takeover,
            "window_bits": self.window_bits,
            "mem_level": self.mem_level,
        }

    def __repr__(self):
        """
        Returns Python object representation that can be eval'ed to reconstruct the object.

        :returns: Python string representation.
        :rtype: str
        """
        return (
            f"PerMessageDeflateResponseAccept(response = {self.response.__repr__()}, no_context_takeover = {self.no_context_takeover}, window_bits = {self.window_bits}, mem_level = {self.mem_level})"
        )


# noinspection PyArgumentList
class PerMessageDeflate(PerMessageCompress, PerMessageDeflateMixin):
    """
    `permessage-deflate` WebSocket extension processor.
    """

    DEFAULT_WINDOW_BITS = zlib.MAX_WBITS
    DEFAULT_MEM_LEVEL = 8

    @classmethod
    def create_from_response_accept(cls, is_server, accept):
        # accept: instance of PerMessageDeflateResponseAccept
        pmce = cls(
            is_server,
            accept.response.server_no_context_takeover,
            (
                accept.no_context_takeover
                if accept.no_context_takeover is not None
                else accept.response.client_no_context_takeover
            ),
            accept.response.server_max_window_bits,
            (
                accept.window_bits
                if accept.window_bits is not None
                else accept.response.client_max_window_bits
            ),
            accept.mem_level,
            accept.max_message_size,
        )
        return pmce

    @classmethod
    def create_from_offer_accept(cls, is_server, accept):
        # accept: instance of PerMessageDeflateOfferAccept
        pmce = cls(
            is_server,
            (
                accept.no_context_takeover
                if accept.no_context_takeover is not None
                else accept.offer.request_no_context_takeover
            ),
            accept.request_no_context_takeover,
            (
                accept.window_bits
                if accept.window_bits is not None
                else accept.offer.request_max_window_bits
            ),
            accept.request_max_window_bits,
            accept.mem_level,
            accept.max_message_size,
        )
        return pmce

    def __init__(
        self,
        is_server,
        server_no_context_takeover,
        client_no_context_takeover,
        server_max_window_bits,
        client_max_window_bits,
        mem_level,
        max_message_size=None,
    ):
        self._is_server = is_server

        self.server_no_context_takeover = server_no_context_takeover
        self.client_no_context_takeover = client_no_context_takeover

        self.server_max_window_bits = (
            server_max_window_bits
            if server_max_window_bits != 0
            else self.DEFAULT_WINDOW_BITS
        )
        self.client_max_window_bits = (
            client_max_window_bits
            if client_max_window_bits != 0
            else self.DEFAULT_WINDOW_BITS
        )

        self.mem_level = mem_level if mem_level else self.DEFAULT_MEM_LEVEL
        self.max_message_size = max_message_size  # None means "no limit"

        self._compressor = None
        self._decompressor = None

        # bytes of decompressed output produced for the message currently being
        # received; reset in start_decompress_message() and used to enforce
        # max_message_size across all frames of a message.
        self._decompress_message_size = 0

    def __json__(self):
        return {
            "extension": self.EXTENSION_NAME,
            "is_server": self._is_server,
            "server_no_context_takeover": self.server_no_context_takeover,
            "client_no_context_takeover": self.client_no_context_takeover,
            "server_max_window_bits": self.server_max_window_bits,
            "client_max_window_bits": self.client_max_window_bits,
            "mem_level": self.mem_level,
        }

    def __repr__(self):
        return (
            f"PerMessageDeflate(is_server = {self._is_server}, server_no_context_takeover = {self.server_no_context_takeover}, client_no_context_takeover = {self.client_no_context_takeover}, server_max_window_bits = {self.server_max_window_bits}, client_max_window_bits = {self.client_max_window_bits}, mem_level = {self.mem_level})"
        )

    def start_compress_message(self):
        # compressobj([level[, method[, wbits[, mem_level[, strategy]]]]])
        # http://bugs.python.org/issue19278
        # http://hg.python.org/cpython/rev/c54c8e71b79a
        if self._is_server:
            if self._compressor is None or self.server_no_context_takeover:
                self._compressor = zlib.compressobj(
                    zlib.Z_DEFAULT_COMPRESSION,
                    zlib.DEFLATED,
                    -self.server_max_window_bits,
                    self.mem_level,
                )
        else:
            if self._compressor is None or self.client_no_context_takeover:
                self._compressor = zlib.compressobj(
                    zlib.Z_DEFAULT_COMPRESSION,
                    zlib.DEFLATED,
                    -self.client_max_window_bits,
                    self.mem_level,
                )

    def compress_message_data(self, data):
        return self._compressor.compress(data)

    def end_compress_message(self):
        data = self._compressor.flush(zlib.Z_SYNC_FLUSH)
        return data[:-4]

    def start_decompress_message(self):
        if self._is_server:
            if self._decompressor is None or self.client_no_context_takeover:
                self._decompressor = zlib.decompressobj(-self.client_max_window_bits)
        else:
            if self._decompressor is None or self.server_no_context_takeover:
                self._decompressor = zlib.decompressobj(-self.server_max_window_bits)

        self._decompress_message_size = 0

    def decompress_message_data(self, data, max_output_len=None):
        # The output is bounded by the smaller of two optional caps: the
        # extension-level max_message_size (negotiated, cumulative across all
        # frames of the message) and the per-call max_output_len (the remaining
        # protocol-level budget). If neither is set, decompression is unbounded.
        limits = []
        if self.max_message_size is not None:
            limits.append(self.max_message_size - self._decompress_message_size)
        if max_output_len is not None:
            limits.append(max_output_len)
        if not limits:
            return self._decompressor.decompress(data)

        # Cap output at the tighter remaining budget. zlib treats a max_length
        # of 0 as "unlimited", so once the budget is exhausted we cap the next
        # call at 1 byte: any further real output then lands in unconsumed_tail
        # and triggers the clean rejection below.
        limit = min(limits)
        data = self._decompressor.decompress(data, limit if limit > 0 else 1)
        self._decompress_message_size += len(data)

        # A non-empty unconsumed_tail means more output was available than the
        # budget allowed, i.e. the message exceeds the limit. Reject cleanly
        # instead of silently truncating - truncation both drops application
        # data and corrupts the deflate stream, so the subsequent
        # end_decompress_message() would raise "zlib error -3" on the trailer.
        if self._decompressor.unconsumed_tail:
            raise PayloadExceededError(
                "WebSocket message exceeds decompression limit "
                f"(max_message_size={self.max_message_size}, "
                f"max_output_len={max_output_len})"
            )
        return data

    def end_decompress_message(self):
        # Eat stripped LEN and NLEN field of a non-compressed block added
        # for Z_SYNC_FLUSH.
        self._decompressor.decompress(b"\x00\x00\xff\xff")
